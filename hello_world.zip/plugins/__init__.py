from .hello_world import hello_world

#init plugin

hello_world().register()
